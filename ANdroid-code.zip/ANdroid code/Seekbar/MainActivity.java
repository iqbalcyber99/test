package com.example.fsk23_32.seekbar_cb14143;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double currentBillTotal;
    int currentCustomPercent;

    EditText billtotal, dis1, dis2, dis3, tot1, tot2, tot3, disT, totT;
    TextView customDiscountTextView;
    SeekBar customSeekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentBillTotal = 0.0;
        currentCustomPercent = 18;

        billtotal = (EditText) findViewById(R.id.billtotal);
        dis1 = (EditText) findViewById(R.id.dis1);
        dis2 = (EditText) findViewById(R.id.dis2);
        dis3 = (EditText) findViewById(R.id.dis3);
        tot1 = (EditText) findViewById(R.id.tot1);
        tot2 = (EditText) findViewById(R.id.tot2);
        tot3 = (EditText) findViewById(R.id.tot3);
        disT = (EditText) findViewById(R.id.disT);
        totT = (EditText) findViewById(R.id.totT);
        customDiscountTextView = (TextView) findViewById(R.id.seekbvalue);
        customSeekBar = (SeekBar) findViewById(R.id.seekBar);


        billtotal.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                currentBillTotal = Double.parseDouble(s.toString());
                updateStandard (); //update 10,15,20 % edit text
                updateCustom(); //update custom discount edit text
            }
        });

        customSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                currentCustomPercent=seekBar.getProgress();
                updateCustom();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }
    public void updateStandard () {
        double tenPercentD = currentBillTotal *0.1;
        double tenPercentT = currentBillTotal - tenPercentD;

        dis1.setText(String.format("%.02f",tenPercentD));
        tot1.setText(String.format("%.02f",tenPercentT));

        double fifteenPercentD = currentBillTotal *0.15;
        double fifteenPercentT = currentBillTotal - fifteenPercentD;

        dis2.setText(String.format("%.02f",fifteenPercentD));
        tot2.setText(String.format("%.02f",fifteenPercentT));

        double twentyPercentD = currentBillTotal *0.20;
        double twentyPercentT = currentBillTotal - twentyPercentD;

        dis3.setText(String.format("%.02f",twentyPercentD));
        tot3.setText(String.format("%.02f",twentyPercentT));
    }

    public void updateCustom () {
        customDiscountTextView.setText(currentCustomPercent + "%");

        double customDiscount = currentBillTotal * currentCustomPercent /100;
        double customTotal = currentBillTotal - customDiscount;

        disT.setText(String.format("%.02f",customDiscount));
        totT.setText(String.format("%.02f",customTotal));


    }
}